// CLI Proxy — /api/google-news
// Forwards to Google News RSS, parses into JSON. Free, no API key.

const CACHE_TTL_SECONDS = 60 * 60;

function parseRSS(xml) {
  // Minimal RSS parser — Google News items have <title>, <link>, <pubDate>, <source>
  const items = [];
  const itemRe = /<item>([\s\S]*?)<\/item>/g;
  const get = (block, tag) => {
    const m = block.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`));
    if (!m) return null;
    return m[1].replace(/^<!\[CDATA\[/, '').replace(/\]\]>$/, '').trim();
  };
  let m;
  while ((m = itemRe.exec(xml)) !== null) {
    const block = m[1];
    items.push({
      title: get(block, 'title'),
      link: get(block, 'link'),
      pubDate: get(block, 'pubDate'),
      source: get(block, 'source'),
    });
  }
  return items;
}

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-cli-token');
    return res.status(204).end();
  }
  res.setHeader('Access-Control-Allow-Origin', '*');
  if (req.method !== 'GET') return res.status(405).json({ error: 'Use GET' });

  const q = req.query.q || req.query.query;
  if (!q) return res.status(400).json({ error: 'Missing q param' });

  try {
    const url = `https://news.google.com/rss/search?q=${encodeURIComponent(q)}&hl=en-US&gl=US&ceid=US:en`;
    const r = await fetch(url);
    if (!r.ok) return res.status(r.status).json({ error: `Google News ${r.status}` });
    const xml = await r.text();
    const items = parseRSS(xml).slice(0, 30);
    res.setHeader('Cache-Control', `public, max-age=${CACHE_TTL_SECONDS}, s-maxage=${CACHE_TTL_SECONDS}`);
    return res.status(200).json({ query: q, items, fetchedAt: new Date().toISOString() });
  } catch (e) {
    return res.status(500).json({ error: 'Google News fetch failed: ' + e.message });
  }
}
