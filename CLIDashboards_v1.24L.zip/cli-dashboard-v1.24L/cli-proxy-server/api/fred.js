// CLI Proxy — /api/fred
// Forwards to FRED API. Requires FRED_API_KEY env var (free at fredaccount.stlouisfed.org/apikey).
// Cached 24h since most series update monthly.

const CACHE_TTL_SECONDS = 24 * 60 * 60;

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-cli-token');
    return res.status(204).end();
  }
  res.setHeader('Access-Control-Allow-Origin', '*');
  if (req.method !== 'GET') return res.status(405).json({ error: 'Use GET' });

  const apiKey = process.env.FRED_API_KEY;
  if (!apiKey) return res.status(500).json({ error: 'FRED_API_KEY not set on proxy' });

  const seriesParam = req.query.series || 'DGS10,UNRATE,CPIAUCSL,SP500';
  const ids = seriesParam.split(',').map(s => s.trim()).filter(Boolean);
  if (ids.length === 0) return res.status(400).json({ error: 'No series IDs' });
  if (ids.length > 10) return res.status(400).json({ error: 'Max 10 series per request' });

  try {
    const out = {};
    // Fetch each series in parallel
    const results = await Promise.allSettled(ids.map(async id => {
      const url = `https://api.stlouisfed.org/fred/series/observations?series_id=${id}&api_key=${apiKey}&file_type=json&limit=10&sort_order=desc`;
      const r = await fetch(url);
      if (!r.ok) throw new Error(`FRED ${id} ${r.status}`);
      const data = await r.json();
      const obs = data.observations || [];
      const latest = obs[0];
      const previous = obs[1];
      out[id] = {
        label: id,
        value: latest ? parseFloat(latest.value) : null,
        asOf: latest?.date || null,
        wow: latest && previous ? Number((parseFloat(latest.value) - parseFloat(previous.value)).toFixed(3)) : null,
      };
    }));
    res.setHeader('Cache-Control', `public, max-age=${CACHE_TTL_SECONDS}, s-maxage=${CACHE_TTL_SECONDS}`);
    return res.status(200).json({ series: out, asOf: new Date().toISOString().split('T')[0] });
  } catch (e) {
    return res.status(500).json({ error: 'FRED fetch failed: ' + e.message });
  }
}
