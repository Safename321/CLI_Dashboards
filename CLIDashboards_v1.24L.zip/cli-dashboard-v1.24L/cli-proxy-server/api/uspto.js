// CLI Proxy — /api/uspto
// Forwards to USPTO PatentsView. Free, no API key.
// Cached 7 days — patents are filed in batches, weekly is plenty.

const CACHE_TTL_SECONDS = 7 * 24 * 60 * 60;

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-cli-token');
    return res.status(204).end();
  }
  res.setHeader('Access-Control-Allow-Origin', '*');
  if (req.method !== 'GET') return res.status(405).json({ error: 'Use GET' });

  const assignee = req.query.assignee;
  if (!assignee) return res.status(400).json({ error: 'Missing assignee' });

  try {
    const twelveMoAgo = new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const q = {
      _and: [
        { _contains: { assignee_organization: assignee } },
        { _gte: { patent_date: twelveMoAgo } },
      ],
    };
    const url = `https://api.patentsview.org/patents/query?q=${encodeURIComponent(JSON.stringify(q))}&f=["patent_number","patent_title","patent_date"]&o={"per_page":50}`;
    const r = await fetch(url);
    if (!r.ok) return res.status(r.status).json({ error: `USPTO ${r.status}` });
    const data = await r.json();
    const patents = data.patents || [];
    const out = {
      assignee,
      last12mo: patents.length,
      recent: patents.slice(0, 10).map(p => ({
        title: p.patent_title,
        filedAt: p.patent_date,
        number: p.patent_number,
      })),
    };
    res.setHeader('Cache-Control', `public, max-age=${CACHE_TTL_SECONDS}, s-maxage=${CACHE_TTL_SECONDS}`);
    return res.status(200).json(out);
  } catch (e) {
    return res.status(500).json({ error: 'USPTO fetch failed: ' + e.message });
  }
}
