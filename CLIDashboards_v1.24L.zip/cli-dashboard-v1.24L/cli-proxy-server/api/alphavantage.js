// CLI Proxy — /api/alphavantage
// Forwards to Alpha Vantage. Requires ALPHAVANTAGE_API_KEY env var.
// Free tier: 25 calls/day. Premium $50/mo: 75 calls/min.
// Cached 15min — stock prices change frequently but minute-by-minute isn't needed for behavioral dashboard.

const CACHE_TTL_SECONDS = 15 * 60;

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-cli-token');
    return res.status(204).end();
  }
  res.setHeader('Access-Control-Allow-Origin', '*');
  if (req.method !== 'GET') return res.status(405).json({ error: 'Use GET' });

  const apiKey = process.env.ALPHAVANTAGE_API_KEY;
  if (!apiKey) return res.status(500).json({ error: 'ALPHAVANTAGE_API_KEY not set on proxy' });

  const ticker = req.query.ticker;
  if (!ticker) return res.status(400).json({ error: 'Missing ticker' });

  try {
    const url = `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${ticker}&apikey=${apiKey}`;
    const r = await fetch(url);
    if (!r.ok) return res.status(r.status).json({ error: `Alpha Vantage ${r.status}` });
    const data = await r.json();
    const quote = data['Global Quote'] || {};
    const out = {
      ticker,
      price: parseFloat(quote['05. price']) || null,
      change: parseFloat(quote['09. change']) || null,
      changePercent: quote['10. change percent'] ? parseFloat(quote['10. change percent']) : null,
      volume: parseInt(quote['06. volume']) || null,
      asOf: quote['07. latest trading day'] || null,
    };
    res.setHeader('Cache-Control', `public, max-age=${CACHE_TTL_SECONDS}, s-maxage=${CACHE_TTL_SECONDS}`);
    return res.status(200).json(out);
  } catch (e) {
    return res.status(500).json({ error: 'Alpha Vantage fetch failed: ' + e.message });
  }
}
