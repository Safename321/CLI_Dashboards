// CLI Proxy — /api/chat
// Vercel serverless function that forwards AI Mentor requests to Anthropic.
// Deploy this to the cli-proxy.vercel.app repo (the proxy that already
// serves /api/sec-data) under /api/chat.js.
//
// REQUIRED ENVIRONMENT VARIABLES (set in Vercel project settings):
//   ANTHROPIC_API_KEY   — your Anthropic API key
//   CLI_PROXY_TOKEN     — shared secret with the dashboard client
//
// The dashboard sends header `x-cli-token: <CLI_PROXY_TOKEN>` on every request.
// Requests without a matching token are rejected with 401, which prevents
// random people who discover the URL from burning through your Anthropic credits.

export default async function handler(req, res) {
  // CORS preflight
  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-cli-token');
    return res.status(204).end();
  }
  res.setHeader('Access-Control-Allow-Origin', '*');

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed. Use POST.' });
  }

  // Token check — set CLI_PROXY_TOKEN in Vercel env vars for this proxy
  const expectedToken = process.env.CLI_PROXY_TOKEN;
  if (expectedToken) {
    const provided = req.headers['x-cli-token'];
    if (!provided || provided !== expectedToken) {
      return res.status(401).json({ error: 'Unauthorized: missing or invalid x-cli-token header' });
    }
  } else {
    // Soft warning in dev if token isn't set — the endpoint is open
    console.warn('[cli-proxy/chat] CLI_PROXY_TOKEN env var not set — endpoint is open to anyone');
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'Server misconfigured: ANTHROPIC_API_KEY not set' });
  }

  // Forward to Anthropic
  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;

    const anthropicRes = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: body.model || 'claude-sonnet-4-20250514',
        max_tokens: body.max_tokens || 1024,
        system: body.system,
        messages: body.messages,
      }),
    });

    const data = await anthropicRes.json();
    return res.status(anthropicRes.status).json(data);
  } catch (err) {
    console.error('[cli-proxy/chat] forwarding error:', err);
    return res.status(500).json({ error: 'Proxy forwarding error: ' + (err.message || 'unknown') });
  }
}
