// CLI Proxy — /api/bls-jolts
// Forwards to BLS JOLTS API. Requires BLS_API_KEY env var (free at bls.gov/developers).
// JOLTS series IDs follow pattern JTU<sector>0000000<measure>L (job openings, hires, quits, layoffs)
// Cached 24h — JOLTS releases monthly.

const CACHE_TTL_SECONDS = 24 * 60 * 60;

const SECTOR_NAMES = {
  '000000': 'Total nonfarm',
  '510000': 'Financial activities',
  '540000': 'Professional and business services',
  '610000': 'Education and health services',
  '700000': 'Leisure and hospitality',
};

export default async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-cli-token');
    return res.status(204).end();
  }
  res.setHeader('Access-Control-Allow-Origin', '*');
  if (req.method !== 'GET') return res.status(405).json({ error: 'Use GET' });

  const sector = req.query.sector || '510000';
  const apiKey = process.env.BLS_API_KEY; // optional but increases rate limit

  // Build series IDs for the sector: job openings, hires, quits, layoffs
  const seriesIds = ['JTS', 'JTU'].flatMap(prefix =>
    ['JOL', 'HIL', 'QUL', 'LDL'].map(m => `${prefix}${sector}000000000${m}`)
  );

  try {
    const r = await fetch('https://api.bls.gov/publicAPI/v2/timeseries/data/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        seriesid: seriesIds.slice(0, 4), // BLS rate-limited; one prefix's worth
        startyear: String(new Date().getFullYear() - 1),
        endyear: String(new Date().getFullYear()),
        registrationkey: apiKey,
      }),
    });
    if (!r.ok) return res.status(r.status).json({ error: `BLS ${r.status}` });
    const data = await r.json();
    const series = (data.Results?.series || []);
    const latest = {};
    for (const s of series) {
      const latestObs = s.data?.[0];
      if (!latestObs) continue;
      const measureCode = s.seriesID.slice(-3);
      const measureName = { JOL: 'jobOpenings', HIL: 'hires', QUL: 'quits', LDL: 'layoffs' }[measureCode];
      if (measureName) latest[measureName] = parseInt(latestObs.value) * 1000; // BLS reports in thousands
    }
    res.setHeader('Cache-Control', `public, max-age=${CACHE_TTL_SECONDS}, s-maxage=${CACHE_TTL_SECONDS}`);
    return res.status(200).json({
      sector,
      sectorName: SECTOR_NAMES[sector] || sector,
      latest,
      asOf: series[0]?.data?.[0] ? `${series[0].data[0].year}-${series[0].data[0].periodName}` : null,
    });
  } catch (e) {
    return res.status(500).json({ error: 'BLS fetch failed: ' + e.message });
  }
}
