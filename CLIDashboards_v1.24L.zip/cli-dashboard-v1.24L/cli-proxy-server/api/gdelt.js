// CLI Proxy — /api/gdelt
// Forwards to GDELT 2.0 DOC API. Free, no API key required.
// Response cached at the Vercel edge for 60 minutes (Cache-Control header below).

const CACHE_TTL_SECONDS = 60 * 60; // 1 hour

export default async function handler(req, res) {
  // CORS
  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-cli-token');
    return res.status(204).end();
  }
  res.setHeader('Access-Control-Allow-Origin', '*');

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Use GET' });
  }

  // Optional token check (mirror the chat endpoint pattern)
  const expectedToken = process.env.CLI_PROXY_TOKEN;
  if (expectedToken) {
    const provided = req.headers['x-cli-token'];
    if (!provided || provided !== expectedToken) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
  }

  const query = req.query.query || req.query.q;
  const timespan = req.query.timespan || '7d';
  if (!query) return res.status(400).json({ error: 'Missing query parameter' });

  try {
    const url = `https://api.gdeltproject.org/api/v2/doc/doc?query=${query}&mode=ArtList&format=json&timespan=${timespan}&maxrecords=50`;
    const r = await fetch(url);
    if (!r.ok) return res.status(r.status).json({ error: `GDELT upstream ${r.status}` });
    const data = await r.json();
    res.setHeader('Cache-Control', `public, max-age=${CACHE_TTL_SECONDS}, s-maxage=${CACHE_TTL_SECONDS}`);
    return res.status(200).json(data);
  } catch (e) {
    return res.status(500).json({ error: 'GDELT fetch failed: ' + e.message });
  }
}
