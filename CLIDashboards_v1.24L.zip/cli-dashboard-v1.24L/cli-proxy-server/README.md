# CLI Proxy Server (v1.24G)

This folder contains the Vercel serverless functions the CLI Dashboard uses
to talk to external APIs. It belongs in your **`cli-proxy`** Vercel project
(the one serving `cli-proxy.vercel.app`), not the main dashboard repo.

## Endpoints in this folder

| File | Purpose | Cache TTL | Required env vars |
|------|---------|-----------|--------------------|
| `api/chat.js` | Forwards AI Mentor requests to Anthropic with `x-cli-token` auth | none | `ANTHROPIC_API_KEY`, `CLI_PROXY_TOKEN` |
| `api/gdelt.js` | GDELT 2.0 news + tone scoring | 60 min | (none — free) |
| `api/fred.js` | FRED macro indicators | 24 hr | `FRED_API_KEY` (free at fredaccount.stlouisfed.org/apikey) |
| `api/bls-jolts.js` | BLS JOLTS labor data | 24 hr | `BLS_API_KEY` (optional, raises rate limit, free at bls.gov/developers) |
| `api/google-news.js` | Google News RSS, parsed to JSON | 60 min | (none — free) |
| `api/alphavantage.js` | Stock prices via Alpha Vantage | 15 min | `ALPHAVANTAGE_API_KEY` (free at alphavantage.co) |
| `api/uspto.js` | USPTO PatentsView patent filings | 7 days | (none — free) |
| `api/sec-data.js` | (already deployed) SEC EDGAR | 24 hr | (none — free) |

All endpoints honor `Cache-Control` headers so Vercel's edge cache serves
repeated identical requests from cache without re-hitting the upstream API.
Bandwidth and function invocation cost stays low even with thousands of users.

## Deploy steps

1. **Open your `cli-proxy` Vercel project.**
2. **Copy each `api/*.js` file** into the corresponding location in that project.
3. **Set environment variables** in Vercel project settings → Environment Variables:
   - `ANTHROPIC_API_KEY` — your Anthropic key (already there)
   - `CLI_PROXY_TOKEN` — generate with `openssl rand -hex 32`, share with dashboard
   - `FRED_API_KEY` — free at fredaccount.stlouisfed.org/apikey
   - `ALPHAVANTAGE_API_KEY` — free at alphavantage.co
   - `BLS_API_KEY` — optional but recommended, free at bls.gov/developers
4. **Redeploy** (Vercel will rebuild automatically on push).

## Configure the dashboard

In `cli-dashboard-v1.24G/.env`:

```
VITE_ANTHROPIC_API_KEY=  (leave empty — server-side now)
VITE_CLI_PROXY_TOKEN=<same value as CLI_PROXY_TOKEN in Vercel>
```

Then in `src/App.jsx`, find `const ENABLE_PROXY_AUTH = false;` and flip
to `true` to start sending the auth header on `/api/chat` calls.

## Testing each endpoint

```bash
# GDELT
curl "https://cli-proxy.vercel.app/api/gdelt?query=%22S%26P%20Global%22&timespan=7d" | head

# FRED (with token)
curl "https://cli-proxy.vercel.app/api/fred?series=DGS10,UNRATE" \
  -H "x-cli-token: <your token>"

# Google News
curl "https://cli-proxy.vercel.app/api/google-news?q=S%26P+Global"

# Chat (auth required)
curl -X POST https://cli-proxy.vercel.app/api/chat \
  -H "Content-Type: application/json" \
  -H "x-cli-token: <your token>" \
  -d '{"model":"claude-sonnet-4-20250514","max_tokens":50,"messages":[{"role":"user","content":"hi"}]}'
```

A bare-URL request to `/api/chat` without the token returns 401. All other
endpoints accept the token but don't require it by default — that's a
design choice (those endpoints are read-only to free public APIs, so the
abuse risk is much lower than the chat endpoint).
