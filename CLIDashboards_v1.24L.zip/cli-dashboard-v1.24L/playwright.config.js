// @ts-check
const { defineConfig, devices } = require('@playwright/test');

/**
 * Playwright config for CLI Dashboards
 * Auto-starts the Vite dev server and records video of every test.
 * Videos land in test-results/<test-name>/video.webm
 */
module.exports = defineConfig({
  testDir: './tests',
  timeout: 120 * 1000,
  expect: { timeout: 10 * 1000 },
  fullyParallel: false,            // sequential — one dashboard at a time, cleaner videos
  workers: 1,
  reporter: [['list'], ['html', { open: 'never' }]],

  use: {
    baseURL: 'http://localhost:5173',
    headless: true,                // set to false to watch live
    viewport: { width: 1440, height: 900 },
    video: {
      mode: 'on',                  // record every test, every time
      size: { width: 1440, height: 900 },
    },
    screenshot: 'only-on-failure',
    trace: 'retain-on-failure',
    actionTimeout: 8000,
  },

  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
  ],

  // Auto-launch the Vite dev server before tests; tear down after.
  webServer: {
    command: 'npm run dev',
    url: 'http://localhost:5173',
    reuseExistingServer: !process.env.CI,
    timeout: 60 * 1000,
    stdout: 'pipe',
    stderr: 'pipe',
  },
});
