# CLI Dashboard v1.24E

**Connective Leadership Institute — Executive Dashboard**

## What's New in v1.24E

**Management Challenges dashboard — UX polish**
- ✅ **Rollover popup tooltips** on each of the 9 challenge cards on the right grid. Hover any card to see the CLI Instruments (with primary/secondary labels and rationale), Common Variants (5 subtypes), Risks if Unresolved (red panel), and Goals at Stake (green panel) — all in a single fixed-position popup that smart-positions to fit the viewport.
- ✅ **Larger font sizes throughout** the Management Challenges dashboard. Body text 14→16px, challenge card names 12→15px (the key readability win), instrument badges 10→12px, section headers 15→17px, stats, buttons, fields, and overlay labels all proportionally larger. ~15-25% increase across the board.
- ✅ **Collapsible left-side sections** for Peace Pad, Overlay on Peace Pad, and Active Challenges. Each section's title + description is the clickable header, with a cyan chevron (▼) that rotates -90° when collapsed. The Peace Pad section's chart still flex-grows when expanded.

**Carried forward from v1.24B:**

**New: Scenario Tester (popover modal)**
- ✅ "🔮 Scenario Tester" button added to sidebar above "Update Data"
- ✅ Opens as full-screen popover modal (click-outside-to-close)
- ✅ Generalized engine, **7 persona presets**: CEO (strategic moves), CFO (budget reallocation), CSO (market resilience), CHRO (intervention impact), Trainer (curriculum impact), HR Hiring (selection weighting), Senior/Team Manager (1:1 conversation impact)
- ✅ Persona switcher dropdown — defaults to current user, switch freely to see another role's view
- ✅ 4 sliders per preset, each with baseline marker and bidirectional range
- ✅ Live-updating projected outcomes + total projected impact in $M/yr
- ✅ Caveat banner: explicitly states the tool is directional, not predictive

**New: Scenario Report PDF export**
- ✅ "📄 [Funny PDF copy]" button at bottom of modal
- ✅ Random saying from a 9-item PDF-explicit pool ("Engage scenario PDF", "Bottle this scenario in a PDF", "Crystallize as PDF", etc.)
- ✅ Generates branded HTML PDF with:
  - "The Future" wordmark header in CLI red
  - Tenant name + user email + generation timestamp via `cliReportFooter()`
  - Inputs table (baseline, tested value, change)
  - Projected outcomes table
  - Total impact callout
  - Embedded caveat about linear elasticity

**Removed: 1×1 dead-pixel logo**
- ✅ The hidden CLI wheel logo (rendered at 1px × 1px below the version label) has been deleted entirely
- ✅ Reclaims ~12-15px of sidebar vertical space
- ✅ Eliminates the small "." artifact some users were noticing
- ✅ Stops the browser from downloading 13KB of base64 JPEG for an invisible element

## What's New in v1.24A (carried forward)

**Behavioral-Outcome dashboard — major upgrade**
- ✅ **Pivotable Matrix** replaces the static hypothesis graph
  - Three dropdowns at top: rows axis, columns axis, color-by
  - 6×6 grid with filled cells showing tier + coefficient + CI + n, empty cells showing diagonal hatching
  - Click any cell → opens existing methodology modal with full detail
  - Color modes: Evidence tier · Effect size · Direction (+/−) · Sample size
- ✅ **What-if Simulator** added below the matrix
  - 6 sliders, one per behavioral driver, with visual track showing measured range
  - Live-updating projected outcomes (5 metrics) with confidence-weighted dollar totals
  - Confidence decay: inside measured range = original tier confidence; outside = degrades through Medium → Low → Extrapolated
  - Unweighted + confidence-weighted dollar totals shown side-by-side
  - Reset button restores all sliders to current SPGI baseline

**Sidebar redesign**
- ✅ Thicker, partial-width section dividers (2px, indented from edges)
- ✅ Larger persona title font (15px bold, was 12px)
- ✅ Increased spacing between divider and title for visual breathing room
- ✅ Descriptor font bumped from 9px to 10px
- ✅ "Logout" button added below "Update Data" / "Refresh Data" button
- ✅ Floating sign-out button removed (now sidebar-anchored)
- ✅ "demo for [tenant]" subtitle removed from sidebar header — keeps only "Connective Leadership Dashboards"

**About CLI section — Resources & Links**
- ✅ ConnectiveLeadership.com link (live, opens in new tab)
- ✅ CLI Android app placeholder (Coming Soon)
- ✅ CLI iOS app placeholder (Coming Soon)
- ✅ Each card: icon, status badge (Live/Coming soon), name, one-line description

## What's New in v1.24 (carried forward)

**Multi-tenant routing**
- ✅ Login by email + password (`CLI2026!` for all tenants)
- ✅ Email domain determines tenant: `@zoetis.com` → Zoetis · `@snpglobal.com` → S&P Global · anything else → generic white-label
- ✅ Tenant config exported from `src/LoginGate.jsx` as `TENANTS` (id, companyName, ticker, subtitle, accentColor, hasLiveData, emptyState)
- ✅ Active tenant published on `window.__CLI_TENANT__` for dashboards to read
- ✅ Floating sign-out button now shows the current tenant name

**Zoetis empty-state tenant**
- ✅ Zoetis tenant configured with `emptyState: true` — DemoDataBanner shows amber "awaiting data from CLI Flutter app pipeline" banner
- ✅ Empty state will flip to populated when `hasLiveData: true` is set after the Flutter → database → dashboard pipeline is verified
- ✅ No synthesized data — tenant is the integration-test target, not a content demo

**Sidebar tenant-aware**
- ✅ Sidebar subtitle dynamically reads from active tenant ("demo for S&P Global", "demo for Zoetis", "white-label demo")
- ✅ "The Future" wordmark unchanged — platform brand is consistent across tenants

**Security caveat (carried forward + reinforced)**
- All tenant data ships in the same JS bundle — anyone with DevTools can inspect all tenants. This is acceptable for internal sales demos (you control who gets the password), not for production multi-tenant SaaS
- For real per-tenant data isolation, move to Vercel/Netlify + serverless auth + per-tenant API endpoints

## What's New in v1.23A (carried forward)

**Branding — "The Future" platform name**
- ✅ Replaced "S&P Global" red text in sidebar header with **"The Future"** wordmark (Arial Black, bold, red, 44pt)
- ✅ Per the v1.19 platform-naming decision finally landing in code
- ✅ Subtitle now reads "Connective Leadership Dashboards · demo for S&P Global"
- ✅ CLI logo retained at left of the wordmark

**Real-vs-sample data clarity**
- ✅ DemoDataBanner upgraded — two-tone legend showing what's real (SEC EDGAR financials) vs demo (OASI scores, sentiment, headcount)
- ✅ Visible across 7 dashboards (CEO Advisory, Investor Relations, Sentiment, Customer Health, Employee Leading, Investor Behavior, Personnel)

**PDF-explicit button humor**
- ✅ All 24 sayings in `REPORT_BUTTON_SAYINGS` now name "PDF" explicitly so users always know what format they're getting
- ✅ "To PDF or not? (PDF.)" · "PDF, please" · "Get this in a PDF, stat" · "Houston, we have a PDF" · 20 more
- ✅ Applied to: SWOT Full Report, Board Packet, Hiring Full Audit, RecommendationPanel default, AI Mentor downloads

**Individual ASI Lookup — partial implementation noted**
- ⚠️ The "with PDF display" piece of the original feature spec was never built (flagged "needs API specs" in Feb 2026, never resolved)
- ✅ TODO marker added at `handleSend` in `IndividualASIDashboard` documenting exactly what's needed for v1.24E+: backend dispatch API, per-employee PDF generator function, inline render or download trigger

## What's New in v1.23 (carried forward)

**Branch reconciliation**
- ✅ Single canonical build — all v1.21/v1.21A/v1.22 features merged
- ✅ 7-persona sidebar (CEO / CFO / CSO / CHRO - Chief of HR / Trainer / HR Hiring / Senior Team Manager / Utility)
- ✅ Option-3 sidebar styling — hairline divider + bold persona heading + 9px descriptor underneath
- ✅ Strategic SWOT dashboard (CEO Advisory)
- ✅ Behavioral-Outcome Patterns, Scenario Modeling, Early Warning probability-of-breach, "What changed" feed
- ✅ Login gate (admin / CLI2026!) — change password via `LoginGate.jsx` PASSWORD_HASH
- ✅ Live timestamps — "Data as of" and "What changed" window auto-update to current time

**Humor pass on download buttons**
- ✅ Random funny saying picked from `REPORT_BUTTON_SAYINGS` (24 sayings)
- ✅ Applied to generic download buttons: SWOT Full Report, Board Packet, Hiring Full Audit, RecommendationPanel
- ✅ Left content-descriptive buttons unchanged ("Explain the OASI", "Generate PDF Analysis", "Talking Pts")

**Security caveats (carried forward)**
- Login gate requires HTTPS or localhost (`crypto.subtle` unavailable on `file://` or LAN HTTP)
- This is a *soft gate* — adequate for keeping the demo out of search engines, not a real auth layer
- Rotate password: `echo -n "NewPassword" | shasum -a 256` → paste into `src/LoginGate.jsx`

**Access control**
- ✅ Login gate — username + password prompt on page load
- ✅ Default credentials: `admin` / `CLI2026!` (change in `src/LoginGate.jsx` → `PASSWORD_HASH`)
- ✅ Session-based: stays signed in for the browser session, logs out on tab close
- ✅ Floating "Sign out" button in bottom-right when authenticated
- ✅ Password stored as SHA-256 hash, not plaintext

**Security trade-offs (read before deploying)**
- This is a *soft gate* — adequate for keeping the demo out of search engines and casual visitors
- The dashboard's React bundle still loads to the browser; a determined visitor with DevTools could inspect bundle contents
- If the repo is public, source code is publicly readable on GitHub regardless of this gate
- Requires HTTPS or localhost; on plain HTTP LAN or `file://` the gate will surface a `crypto.subtle unavailable` message
- To rotate the password: `echo -n "NewPassword" | shasum -a 256` → paste hash into `LoginGate.jsx`

## What's New in v1.21 (carried forward)

**Advanced analytics — predictive dashboards earn their name**
- ✅ **Behavioral-Outcome Patterns** (renamed from Causal Analysis) — replaces 2 static correlations with 6 evidence-tiered relationships (cross-sectional / time-lagged / quasi-experimental), interactive SVG hypothesis graph, effect sizes translated to dollars, click-through methodology modals with n / window / CI / caveats
- ✅ **Scenario Modeling** — configurable input sliders (cost reduction, annual billing, hiring pause, training investment), live recalculation of outputs, fan chart with 10/50/90 percentile bands, sensitivity tornado, capital-allocation lens (fund/defer table), **6-prediction calibration history** showing model error ±13% vs. actual
- ✅ **Early Warning KPIs** — probability-of-breach forecasting per KPI (linear-trend + Gaussian-noise model, 90-day horizon), dollar-impact column tying each KPI to budget risk, methodology footer

**CEO Advisory**
- ✅ "What changed since your last login" feed at the top — 5 most material movements in the last 24h, color-coded by severity, linked to source dashboard
- ✅ Stale "Dec 19, 2020" timestamp fixed to current (May 18, 2026 10:54 AM)

**Sentiment Analysis**
- ✅ External Data Sources scaffold — Glassdoor, Layoffs.fyi, LinkedIn cards calibrating internal OASI against public signal, with explicit confirmation of internal-vs-external convergence

**Information architecture**
- ✅ Sidebar resorted by 7 personas (CEO, CFO, CSO, CHRO, Trainer, HR Hiring, Senior/Team Manager) with shared dashboards positioned at the section seams for multi-role visibility

**Date sweep**
- ✅ Stale 2020-era dates in Board Packet and Investor Update generators replaced with current 2026 quarter references

## Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Add your Anthropic API key
Edit the `.env` file in the project root:
```
VITE_ANTHROPIC_API_KEY=your_key_here
```
Get your key at: https://console.anthropic.com

### 3. Run locally
```bash
npm run dev
```

### 4. Build for production
```bash
npm run build
```

## Stack
- React + Vite
- Tailwind CSS
- Recharts
- Anthropic Claude API (claude-sonnet-4-20250514)

## CLI AI Mentor Capabilities
| Action | What it does |
|--------|-------------|
| ⚡ CEO Advisory | Strategic priorities + CLI Achieving Styles intervention |
| 📋 Board Narrative | Formal board packet section from live dashboard data |
| 🔍 Sentiment & Risks | Risk flags with 🔴🟡🟢 severity levels |
| 💬 Ask Anything | Free-form Q&A with full dashboard + CLI framework context |

© 2026 Connective Leadership Institute
