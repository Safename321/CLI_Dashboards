import { useState, useEffect } from 'react';

// ─── Multi-tenant configuration ──────────────────────────────────────────
// Password is the same for all tenants (CLI2026!).
// Domain matching is case-insensitive; substring match on the email address.
// Any email not matching a known domain routes to the GENERIC tenant.

export const TENANTS = {
  zoetis: {
    id: 'zoetis',
    domainMatch: '@zoetis.com',
    companyName: 'Zoetis',
    ticker: 'ZTS',
    sidebarSubtitle: 'demo for Zoetis',
    accentColor: '#FF671F',
    hasLiveData: false,
    emptyState: true,
  },
  spgi: {
    id: 'spgi',
    domainMatch: '@snpglobal.com',
    companyName: 'S&P Global',
    ticker: 'SPGI',
    sidebarSubtitle: 'demo for S&P Global',
    accentColor: '#E00000',
    hasLiveData: true,
    emptyState: false,
  },
  generic: {
    id: 'generic',
    domainMatch: null,
    companyName: 'CLI Demo',
    ticker: null,
    sidebarSubtitle: 'white-label demo',
    accentColor: '#E00000',
    hasLiveData: true,
    emptyState: false,
  },
};

function detectTenant(email) {
  const lower = (email || '').toLowerCase().trim();
  for (const key of Object.keys(TENANTS)) {
    const t = TENANTS[key];
    if (t.domainMatch && lower.includes(t.domainMatch)) {
      return t;
    }
  }
  return TENANTS.generic;
}

const PASSWORD_HASH = '67a56a9708e14f53063738f5faef7a2e27459c7d344a73aa067c14949eceab84';
const SESSION_KEY = 'cli_authed_v124';
const TENANT_KEY  = 'cli_tenant_v124';
const EMAIL_KEY   = 'cli_email_v124';

async function sha256(text) {
  if (typeof crypto === 'undefined' || !crypto.subtle) {
    throw new Error('crypto.subtle unavailable — open via HTTPS or localhost, not file://');
  }
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

export default function LoginGate({ children }) {
  const [authed, setAuthed] = useState(false);
  const [tenant, setTenant] = useState(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    try {
      if (sessionStorage.getItem(SESSION_KEY) === '1') {
        const storedTenant = sessionStorage.getItem(TENANT_KEY);
        if (storedTenant && TENANTS[storedTenant]) {
          setTenant(TENANTS[storedTenant]);
          if (typeof window !== 'undefined') window.__CLI_TENANT__ = TENANTS[storedTenant];
          setAuthed(true);
        }
      }
    } catch (e) {}
    setChecking(false);
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const cleanEmail = email.trim();
      const cleanPass = password.trim();

      if (!cleanEmail || cleanEmail.indexOf('@') < 0) {
        setError('Enter an email address (any domain works)');
        setLoading(false);
        return;
      }

      const hash = await sha256(cleanPass);
      if (hash !== PASSWORD_HASH) {
        setError('Incorrect password');
        await new Promise(r => setTimeout(r, 700));
        setLoading(false);
        return;
      }

      const detected = detectTenant(cleanEmail);
      console.log('[LoginGate] routed to tenant:', detected.id);

      try {
        sessionStorage.setItem(SESSION_KEY, '1');
        sessionStorage.setItem(TENANT_KEY, detected.id);
        sessionStorage.setItem(EMAIL_KEY, cleanEmail);
      } catch (e) {}

      if (typeof window !== 'undefined') window.__CLI_TENANT__ = detected;
      setTenant(detected);
      setAuthed(true);
    } catch (err) {
      console.error('[LoginGate] error:', err);
      setError('Login failed: ' + err.message);
    }
    setLoading(false);
  };

  const handleLogout = () => {
    try {
      sessionStorage.removeItem(SESSION_KEY);
      sessionStorage.removeItem(TENANT_KEY);
      sessionStorage.removeItem(EMAIL_KEY);
    } catch (e) {}
    if (typeof window !== 'undefined') window.__CLI_TENANT__ = null;
    setAuthed(false);
    setTenant(null);
    setEmail('');
    setPassword('');
  };

  if (checking) {
    return <div style={{
      minHeight: '100vh', backgroundColor: '#0f172a',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: '#64748b', fontFamily: 'system-ui, sans-serif'
    }}>Loading…</div>;
  }

  if (authed && tenant) {
    return <>{children}</>;
  }

  return (
    <div style={{
      minHeight: '100vh', backgroundColor: '#0f172a',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: 'system-ui, -apple-system, "Segoe UI", sans-serif', padding: '20px'
    }}>
      {/* Override Chrome/Edge autofill to keep dark bg + white text */}
      <style>{`
        input.cli-login-input:-webkit-autofill,
        input.cli-login-input:-webkit-autofill:hover,
        input.cli-login-input:-webkit-autofill:focus,
        input.cli-login-input:-webkit-autofill:active {
          -webkit-text-fill-color: #ffffff !important;
          -webkit-box-shadow: 0 0 0 1000px #0f172a inset !important;
          caret-color: #ffffff !important;
          transition: background-color 9999s ease-in-out 0s;
        }
        input.cli-login-input::placeholder { color: #64748b; }
      `}</style>

      <form onSubmit={handleSubmit} style={{
        backgroundColor: '#1e293b', border: '1px solid #334155',
        borderRadius: '12px', padding: '32px', width: '100%',
        maxWidth: '420px', boxShadow: '0 20px 25px -5px rgba(0,0,0,0.3)'
      }}>
        <div style={{ marginBottom: '8px' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: '8px' }}>
            <span style={{ color: '#E00000', fontFamily: "'Arial Black', Arial, sans-serif", fontWeight: 'bold', fontSize: '24px' }}>The Future</span>
            <span style={{ color: '#94a3b8', fontSize: '12px' }}>· CLI</span>
          </div>
          <p style={{ color: '#94a3b8', fontSize: '13px', margin: '6px 0 22px 0' }}>
            Connective Leadership Institute · Behavioral intelligence platform
          </p>
        </div>

        <label style={{ display: 'block', marginBottom: '14px' }}>
          <span style={{ display: 'block', color: '#cbd5e1', fontSize: '12px', fontWeight: 600, marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Email</span>
          <input
            className="cli-login-input"
            type="email" autoFocus autoComplete="username" placeholder="admin@company.com"
            value={email} onChange={e => setEmail(e.target.value)}
            style={{ width: '100%', backgroundColor: '#0f172a', border: '1px solid #475569', color: '#ffffff', borderRadius: '6px', padding: '8px 10px', fontSize: '14px', boxSizing: 'border-box', outline: 'none' }}
            onFocus={(e) => { e.target.style.borderColor = '#06b6d4'; }}
            onBlur={(e) => { e.target.style.borderColor = '#475569'; }}
          />
          <span style={{ color: '#64748b', fontSize: '10px', marginTop: '2px', display: 'block' }}>
            admin@zoetis.com → Zoetis · admin@snpglobal.com → S&P Global · any other → white-label
          </span>
        </label>

        <label style={{ display: 'block', marginBottom: '8px' }}>
          <span style={{ display: 'block', color: '#cbd5e1', fontSize: '12px', fontWeight: 600, marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Password</span>
          <input
            className="cli-login-input"
            type={showPassword ? 'text' : 'password'}
            autoComplete="current-password"
            value={password} onChange={e => setPassword(e.target.value)}
            style={{ width: '100%', backgroundColor: '#0f172a', border: '1px solid #475569', color: '#ffffff', borderRadius: '6px', padding: '8px 10px', fontSize: '14px', boxSizing: 'border-box', outline: 'none' }}
            onFocus={(e) => { e.target.style.borderColor = '#06b6d4'; }}
            onBlur={(e) => { e.target.style.borderColor = '#475569'; }}
          />
        </label>

        <label style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '16px', cursor: 'pointer', userSelect: 'none' }}>
          <input
            type="checkbox"
            checked={showPassword}
            onChange={e => setShowPassword(e.target.checked)}
            style={{ accentColor: '#06b6d4', cursor: 'pointer' }}
          />
          <span style={{ color: '#94a3b8', fontSize: '12px' }}>Show password</span>
        </label>

        {error && (
          <div style={{ color: '#f87171', fontSize: '12px', marginBottom: '12px', padding: '6px 10px', backgroundColor: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: '4px' }}>{error}</div>
        )}

        <button
          type="submit" disabled={loading || !email || !password}
          style={{
            width: '100%',
            backgroundColor: (loading || !email || !password) ? '#475569' : '#0891b2',
            color: '#ffffff', border: 'none', borderRadius: '6px',
            padding: '10px', fontSize: '14px', fontWeight: 600,
            cursor: (loading || !email || !password) ? 'default' : 'pointer',
            transition: 'background-color 0.15s'
          }}
          onMouseOver={(e) => { if (!loading && email && password) e.currentTarget.style.backgroundColor = '#06b6d4'; }}
          onMouseOut={(e) => { if (!loading && email && password) e.currentTarget.style.backgroundColor = '#0891b2'; }}
        >{loading ? 'Checking…' : 'Sign in'}</button>

        <p style={{ color: '#64748b', fontSize: '11px', marginTop: '20px', marginBottom: 0, textAlign: 'center' }}>v1.24L · For authorized prospects only</p>
      </form>
    </div>
  );
}
