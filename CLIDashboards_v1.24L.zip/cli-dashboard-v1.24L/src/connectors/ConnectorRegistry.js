// CLI Dashboards — Connector Registry & Orchestrator
//
// One tenant = one registry instance. Handles parallel fan-out, freshness
// scheduling, and result aggregation. The Tenant Config screen mutates the
// registry by toggling enable state.

export class ConnectorRegistry {
  constructor() {
    this.connectors = new Map(); // key: `${domain}:${connectorId}`
  }

  register(connector, id = null) {
    const key = `${connector.constructor.domain}:${id || connector.constructor.label}`;
    this.connectors.set(key, connector);
    return key;
  }

  unregister(key) { return this.connectors.delete(key); }
  get(key) { return this.connectors.get(key); }

  list() {
    return Array.from(this.connectors.entries()).map(([key, c]) => ({
      key, ...c.status(),
    }));
  }

  byDomain() {
    const out = {};
    for (const [key, c] of this.connectors.entries()) {
      const d = c.constructor.domain;
      if (!out[d]) out[d] = [];
      out[d].push({ key, connector: c });
    }
    return out;
  }

  // Get the most recent successful payload for a domain (preferring real over mock)
  getLatestForDomain(domain) {
    let chosen = null;
    for (const c of this.connectors.values()) {
      if (c.constructor.domain !== domain) continue;
      if (!c.lastPayload) continue;
      // Prefer non-mock if both exist
      if (!chosen || (chosen.constructor.isMock && !c.constructor.isMock)) {
        chosen = c;
      }
    }
    return chosen ? chosen.lastPayload : null;
  }

  // Helper: derive the dashboard's PR-crisis signal from the news connector
  derivePrCrisis() {
    const news = this.getLatestForDomain('news');
    if (!news) return { active: false, source: null, reason: 'no news connector' };
    return {
      active: !!news.crisisActive,
      source: news.source || 'unknown',
      sentimentScore: news.sentimentScore ?? null,
      recentNegativeCount: news.recentNegativeCount ?? 0,
      reason: news.crisisActive
        ? `${news.recentNegativeCount} negative articles in last 24h`
        : 'no crisis signal detected',
    };
  }

  // Run every enabled connector in parallel
  async runAll({ onProgress } = {}) {
    const entries = Array.from(this.connectors.entries());
    if (entries.length === 0) {
      return { ok: true, results: {}, errors: [], startedAt: new Date().toISOString() };
    }
    const startedAt = new Date().toISOString();
    if (onProgress) onProgress({ phase: 'start', total: entries.length, completed: 0 });
    let completed = 0;
    const settled = await Promise.allSettled(
      entries.map(async ([key, c]) => {
        const r = await c.fetch();
        completed++;
        if (onProgress) onProgress({ phase: 'progress', total: entries.length, completed, key });
        return { key, result: r };
      })
    );
    const results = {};
    const errors = [];
    for (const s of settled) {
      if (s.status === 'fulfilled') {
        const { key, result } = s.value;
        results[key] = result;
        if (!result.ok && !result.skipped) {
          errors.push({ key, error: result.error });
        }
      } else {
        errors.push({ key: 'unknown', error: s.reason?.message || String(s.reason) });
      }
    }
    if (onProgress) onProgress({ phase: 'done', total: entries.length, completed });
    return { ok: errors.length === 0, results, errors, startedAt, finishedAt: new Date().toISOString() };
  }
}

// Default registry constructor for the SPGI demo / pre-revenue setup.
// All free public-data connectors get registered as MOCK by default so the
// dashboard ships demo-ready; flip to real implementations in Tenant Config
// once you have API keys and proxy endpoints deployed.
export function buildDefaultRegistry({
  // Financial
  SECEdgarFinancialConnector,
  // Social sentiment
  MockSocialSentimentConnector,
  // News (v1.24G)
  MockNewsConnector, GDELTNewsConnector,
  // Macro (v1.24G)
  MockMacroConnector,
  // Markets (v1.24G)
  MockMarketsConnector,
  // Innovation (v1.24G)
  MockInnovationConnector,
  // Owned social (v1.24G)
  MockOwnedSocialConnector,
  // Culture (v1.24G)
  MockCultureConnector,
  // HRIS (v1.24G)
  MockHRISConnector,
  // Customer health (v1.24G)
  MockCustomerHealthConnector,
} = {}) {
  const reg = new ConnectorRegistry();

  if (SECEdgarFinancialConnector) {
    reg.register(new SECEdgarFinancialConnector({
      cik: '0000064040', ticker: 'SPGI',
      refreshMinutes: 60 * 24,
    }), 'sec-spgi');
  }
  if (MockSocialSentimentConnector) {
    reg.register(new MockSocialSentimentConnector({
      companyName: 'S&P Global',
      handles: { x: '@SPGlobal', linkedin: 'company/sp-global', facebook: 'SPGlobalInc', instagram: 'spglobal', tiktok: '' },
      hashtags: ['#SPGlobal', '#SPGI'],
      refreshMinutes: 60,
    }), 'social-mock');
  }
  if (MockNewsConnector) {
    reg.register(new MockNewsConnector({
      companyName: 'S&P Global', refreshMinutes: 60,
    }), 'news-mock');
  }
  if (MockMacroConnector) {
    reg.register(new MockMacroConnector({ refreshMinutes: 60 * 24 }), 'macro-mock');
  }
  if (MockMarketsConnector) {
    reg.register(new MockMarketsConnector({ ticker: 'SPGI', refreshMinutes: 15 }), 'markets-mock');
  }
  if (MockInnovationConnector) {
    reg.register(new MockInnovationConnector({
      companyName: 'S&P Global', refreshMinutes: 7 * 24 * 60,
    }), 'innovation-mock');
  }
  if (MockOwnedSocialConnector) {
    reg.register(new MockOwnedSocialConnector({
      pageName: 'S&P Global Official', refreshMinutes: 60,
    }), 'owned-social-mock');
  }
  if (MockCultureConnector) {
    reg.register(new MockCultureConnector({
      employerName: 'S&P Global', refreshMinutes: 24 * 60,
    }), 'culture-mock');
  }
  if (MockHRISConnector) {
    reg.register(new MockHRISConnector({
      employerName: 'S&P Global', refreshMinutes: 60,
    }), 'hris-mock');
  }
  if (MockCustomerHealthConnector) {
    reg.register(new MockCustomerHealthConnector({ refreshMinutes: 30 }), 'customer-health-mock');
  }

  return reg;
}
