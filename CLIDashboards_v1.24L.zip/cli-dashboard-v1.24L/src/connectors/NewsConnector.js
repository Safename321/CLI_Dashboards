// CLI Dashboards — News Connector
// Domain: news
// Returns: recent mentions, sentiment trend, top headlines, w/w sentiment delta
//
// The dashboard uses this to drive the news-portion of the "PR crisis active"
// signal that's currently hardcoded false. When this connector returns a
// sentimentScore that drops sharply, the dashboard surfaces the alert.

import { BaseConnector } from './BaseConnector.js';

// ─── GDELT 2.0 ────────────────────────────────────────────────────────
// Free, no API key, 15-min refresh, global news with tone scoring.
// Direct API: https://api.gdeltproject.org/api/v2/doc/doc
// CORS: blocked, so production goes through proxy. For dev, set proxyBase=null.
export class GDELTNewsConnector extends BaseConnector {
  static domain = 'news';
  static label = 'GDELT 2.0 (global news + tone)';
  static isMock = false;

  async _fetch() {
    const company = this.config.companyName || 'S&P Global';
    const proxyBase = this.config.proxyBase || 'https://cli-proxy.vercel.app';
    const useProxy = this.config.useProxy !== false;
    const query = encodeURIComponent(`"${company}"`);
    const url = useProxy
      ? `${proxyBase}/api/gdelt?query=${query}&timespan=7d`
      : `https://api.gdeltproject.org/api/v2/doc/doc?query=${query}&mode=ArtList&format=json&timespan=7d&maxrecords=50`;

    const res = await fetch(url);
    if (!res.ok) throw new Error(`GDELT error ${res.status}`);
    const data = await res.json();

    // GDELT returns articles with `tone` field roughly -10 (very negative) to +10 (very positive)
    // We rescale to 0-10 to align with the dashboard's other sentiment scales
    const articles = data.articles || [];
    const tones = articles.map(a => a.tone).filter(t => typeof t === 'number');
    const avgTone = tones.length ? tones.reduce((a, b) => a + b, 0) / tones.length : 0;
    const sentimentScore = Math.max(0, Math.min(10, (avgTone + 10) / 2));

    // PR crisis heuristic: ≥3 articles in last 24h with tone < -3
    const recent = articles.filter(a => {
      if (!a.seendate) return false;
      const ageMs = Date.now() - Date.parse(a.seendate);
      return ageMs < 24 * 60 * 60 * 1000;
    });
    const negativeRecent = recent.filter(a => a.tone < -3);
    const crisisActive = negativeRecent.length >= 3;

    return {
      source: 'GDELT 2.0',
      company,
      volume: articles.length,
      sentimentScore: Number(sentimentScore.toFixed(2)),
      sentimentWoW: null, // w/w delta would need historical baseline
      recentNegativeCount: negativeRecent.length,
      crisisActive,
      topHeadlines: articles.slice(0, 5).map(a => ({
        title: a.title, url: a.url, tone: a.tone, seenAt: a.seendate, source: a.domain,
      })),
    };
  }
}

// ─── Google News RSS ──────────────────────────────────────────────────
// Free, no API key, no rate limit (sensibly), simple RSS feed.
// CORS: blocked, must go through proxy in production.
export class GoogleNewsRSSConnector extends BaseConnector {
  static domain = 'news';
  static label = 'Google News RSS (basic mentions)';
  static isMock = false;

  async _fetch() {
    const company = this.config.companyName || 'S&P Global';
    const proxyBase = this.config.proxyBase || 'https://cli-proxy.vercel.app';
    const url = `${proxyBase}/api/google-news?q=${encodeURIComponent(company)}`;

    const res = await fetch(url);
    if (!res.ok) throw new Error(`Google News proxy error ${res.status}`);
    const data = await res.json();
    return {
      source: 'Google News RSS',
      company,
      volume: data.items?.length || 0,
      sentimentScore: null, // RSS doesn't include sentiment — would need LLM scoring downstream
      topHeadlines: (data.items || []).slice(0, 10).map(i => ({
        title: i.title, url: i.link, publishedAt: i.pubDate, source: i.source,
      })),
    };
  }
}

// ─── NewsAPI commercial stub ──────────────────────────────────────────
// $449/mo for production. Includes sentiment, full article content, history.
// Stub only — set apiKey in config when subscribed.
export class NewsAPIConnector extends BaseConnector {
  static domain = 'news';
  static label = 'NewsAPI ($449/mo commercial)';
  static isMock = false;

  async _fetch() {
    if (!this.config.apiKey) throw new Error('NewsAPI connector requires apiKey in config');
    const proxyBase = this.config.proxyBase || 'https://cli-proxy.vercel.app';
    const company = encodeURIComponent(this.config.companyName || 'S&P Global');
    const res = await fetch(`${proxyBase}/api/newsapi?q=${company}`);
    if (!res.ok) throw new Error(`NewsAPI proxy error ${res.status}`);
    return await res.json();
  }
}

// ─── Mock News (pre-revenue demo) ─────────────────────────────────────
export class MockNewsConnector extends BaseConnector {
  static domain = 'news';
  static label = 'Mock news (demo)';
  static isMock = true;

  async _fetch() {
    const company = this.config.companyName || 'Demo Co';
    // Deterministic mock to keep demo data stable across reloads
    const seed = company.length;
    return {
      source: 'mock',
      company,
      volume: 12 + (seed % 18),
      sentimentScore: Number((6 + (seed % 30) / 10).toFixed(1)),
      sentimentWoW: -0.2,
      recentNegativeCount: 0,
      crisisActive: false,
      topHeadlines: [
        { title: `${company} announces quarterly earnings beat`, tone: 4.5, source: 'reuters.com' },
        { title: `${company} CEO discusses 2026 outlook`, tone: 2.1, source: 'wsj.com' },
        { title: `Analyst maintains buy rating on ${company}`, tone: 3.8, source: 'bloomberg.com' },
      ],
      note: 'MOCK DATA — wire to GDELT or NewsAPI for live signals.',
    };
  }
}
