// CLI Dashboards — Macro Economic Connector
// Domain: macro
// Returns: macro indicators that give context to org-level KPIs.
// Free public data, shared across all customers — zero marginal cost per customer.

import { BaseConnector } from './BaseConnector.js';

// ─── FRED (St. Louis Fed) ─────────────────────────────────────────────
// Free with API key (https://fredaccount.stlouisfed.org/apikey).
// Daily refresh adequate; series like GDP/CPI update monthly anyway.
export class FREDConnector extends BaseConnector {
  static domain = 'macro';
  static label = 'FRED (St. Louis Fed)';
  static isMock = false;

  async _fetch() {
    if (!this.config.apiKey) throw new Error('FRED requires apiKey (free, get at fredaccount.stlouisfed.org/apikey)');
    const proxyBase = this.config.proxyBase || 'https://cli-proxy.vercel.app';
    // Default series: 10Y Treasury, Unemployment Rate, CPI, S&P 500
    const series = this.config.series || ['DGS10', 'UNRATE', 'CPIAUCSL', 'SP500'];
    const url = `${proxyBase}/api/fred?series=${series.join(',')}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`FRED proxy error ${res.status}`);
    const data = await res.json();
    return { source: 'FRED', series: data.series || {}, asOf: data.asOf || null };
  }
}

// ─── BLS JOLTS ────────────────────────────────────────────────────────
// Free with API key. Job Openings, Hires, Quits, Layoffs at sector level —
// crucial context for retention dashboards. Monthly refresh.
export class BLSJoltsConnector extends BaseConnector {
  static domain = 'macro';
  static label = 'BLS JOLTS (hiring/quits/layoffs)';
  static isMock = false;

  async _fetch() {
    const proxyBase = this.config.proxyBase || 'https://cli-proxy.vercel.app';
    const sector = this.config.sector || '510000'; // 510000 = Financial Activities
    const url = `${proxyBase}/api/bls-jolts?sector=${sector}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`BLS JOLTS proxy error ${res.status}`);
    const data = await res.json();
    return {
      source: 'BLS JOLTS',
      sector: data.sectorName || sector,
      latest: data.latest || {},
      trend: data.trend || [],
    };
  }
}

// ─── Mock macro for pre-revenue demo ───────────────────────────────────
export class MockMacroConnector extends BaseConnector {
  static domain = 'macro';
  static label = 'Mock macro indicators (demo)';
  static isMock = true;

  async _fetch() {
    return {
      source: 'mock',
      series: {
        DGS10: { label: '10Y Treasury', value: 4.42, asOf: '2026-05-25', wow: -0.08 },
        UNRATE: { label: 'Unemployment Rate', value: 3.9, asOf: '2026-04-30', mom: 0.1 },
        CPIAUCSL: { label: 'CPI', value: 313.5, asOf: '2026-04-30', yoy: 3.1 },
        SP500: { label: 'S&P 500', value: 5470, asOf: '2026-05-25', wow: 0.4 },
      },
      jolts: {
        sector: 'Financial Activities',
        latest: { jobOpenings: 482000, hires: 119000, quits: 87000, layoffs: 41000 },
      },
      note: 'MOCK DATA — wire to FRED + BLS JOLTS for live macro context.',
    };
  }
}
