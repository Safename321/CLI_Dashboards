// CLI Dashboards — Markets Connector
// Domain: markets
// Returns: stock prices, technical indicators, recent insider activity.
// Free tier: 25 calls/day. $50/mo Premium: 75 calls/min.

import { BaseConnector } from './BaseConnector.js';

export class AlphaVantageConnector extends BaseConnector {
  static domain = 'markets';
  static label = 'Alpha Vantage (stock prices + indicators)';
  static isMock = false;

  async _fetch() {
    if (!this.config.apiKey) throw new Error('Alpha Vantage requires apiKey (free at alphavantage.co)');
    const proxyBase = this.config.proxyBase || 'https://cli-proxy.vercel.app';
    const ticker = this.config.ticker || 'SPGI';
    const url = `${proxyBase}/api/alphavantage?ticker=${ticker}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Alpha Vantage proxy error ${res.status}`);
    const data = await res.json();
    return {
      source: 'Alpha Vantage',
      ticker,
      price: data.price,
      change: data.change,
      changePercent: data.changePercent,
      volume: data.volume,
      week52High: data.week52High,
      week52Low: data.week52Low,
      asOf: data.asOf || null,
    };
  }
}

export class MockMarketsConnector extends BaseConnector {
  static domain = 'markets';
  static label = 'Mock markets data (demo)';
  static isMock = true;

  async _fetch() {
    return {
      source: 'mock',
      ticker: this.config.ticker || 'SPGI',
      price: 487.32,
      change: -2.18,
      changePercent: -0.45,
      volume: 1840000,
      week52High: 525.40,
      week52Low: 410.20,
      asOf: new Date().toISOString().split('T')[0],
      note: 'MOCK DATA — wire to Alpha Vantage for live prices.',
    };
  }
}
