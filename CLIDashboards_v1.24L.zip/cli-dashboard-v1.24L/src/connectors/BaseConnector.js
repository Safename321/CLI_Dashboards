// CLI Dashboards — Base Connector
// All data-source connectors inherit from this class. Provides config,
// freshness tracking, error state, mock-fallback, retry-with-backoff,
// localStorage persistence of last-known payload, and a consistent shape.
//
// Subclasses must implement: async _fetch() returning the connector's payload.
// Subclasses must define: static domain (e.g. 'financial', 'social-sentiment')
// Subclasses must define: static label (display name, shown in Tenant Config)

const STORAGE_PREFIX = 'cli_connector_state_v1__';

export class BaseConnector {
  constructor(config = {}) {
    this.config = config;
    this.tenantId = config.tenantId || 'default';
    this.enabled = config.enabled !== false;
    this.refreshMinutes = config.refreshMinutes || 60;
    this.maxRetries = config.maxRetries ?? 3;
    this.retryBaseMs = config.retryBaseMs ?? 500;
    this.lastFetchAt = null;
    this.lastError = null;
    this.lastPayload = null;
    this.lastSuccessAt = null;
    this._restoreFromStorage();
  }

  // Subclasses override
  static domain = 'base';
  static label = 'Base Connector';
  static isMock = false;
  static requiresOAuth = false;

  // Unique storage key per (domain, tenantId) so multi-tenant doesn't collide
  _storageKey() {
    return STORAGE_PREFIX + this.constructor.domain + '__' + this.tenantId;
  }

  _restoreFromStorage() {
    if (typeof localStorage === 'undefined') return;
    try {
      const raw = localStorage.getItem(this._storageKey());
      if (!raw) return;
      const saved = JSON.parse(raw);
      this.lastFetchAt = saved.lastFetchAt || null;
      this.lastSuccessAt = saved.lastSuccessAt || null;
      this.lastError = saved.lastError || null;
      this.lastPayload = saved.lastPayload || null;
    } catch (e) { /* ignore corrupted state */ }
  }

  _saveToStorage() {
    if (typeof localStorage === 'undefined') return;
    try {
      localStorage.setItem(this._storageKey(), JSON.stringify({
        lastFetchAt: this.lastFetchAt,
        lastSuccessAt: this.lastSuccessAt,
        lastError: this.lastError,
        lastPayload: this.lastPayload,
      }));
    } catch (e) { /* quota or other write failure — ignore */ }
  }

  // Exponential backoff retry wrapper around _fetch
  async _fetchWithRetry() {
    let attempt = 0;
    let lastErr;
    while (attempt <= this.maxRetries) {
      try {
        return await this._fetch();
      } catch (err) {
        lastErr = err;
        if (attempt === this.maxRetries) break;
        // Don't retry on auth/config errors — only on network errors
        if (err.message && /requires|missing|in config|apiKey/i.test(err.message)) break;
        const delay = this.retryBaseMs * Math.pow(2, attempt);
        await new Promise(r => setTimeout(r, delay));
        attempt++;
      }
    }
    throw lastErr;
  }

  // Public API used by the orchestrator
  async fetch() {
    if (!this.enabled) {
      return { ok: false, skipped: true, reason: 'disabled' };
    }
    try {
      const payload = await this._fetchWithRetry();
      this.lastFetchAt = new Date().toISOString();
      this.lastSuccessAt = this.lastFetchAt;
      this.lastError = null;
      this.lastPayload = payload;
      this._saveToStorage();
      return {
        ok: true,
        domain: this.constructor.domain,
        label: this.constructor.label,
        isMock: this.constructor.isMock,
        fetchedAt: this.lastFetchAt,
        payload,
      };
    } catch (err) {
      this.lastFetchAt = new Date().toISOString();
      this.lastError = err.message || String(err);
      this._saveToStorage();
      return {
        ok: false,
        domain: this.constructor.domain,
        label: this.constructor.label,
        error: this.lastError,
        fetchedAt: this.lastFetchAt,
        // Stale-but-useful: return the last-known payload even if this fetch failed
        stalePayload: this.lastPayload,
        staleAt: this.lastSuccessAt,
      };
    }
  }

  // Subclasses MUST override
  async _fetch() {
    throw new Error('BaseConnector._fetch() must be implemented by subclass');
  }

  // Freshness helper for the orchestrator's scheduling
  isStale() {
    if (!this.lastSuccessAt) return true;
    const ageMs = Date.now() - new Date(this.lastSuccessAt).getTime();
    return ageMs > this.refreshMinutes * 60 * 1000;
  }

  // Status for the Tenant Config UI
  status() {
    return {
      domain: this.constructor.domain,
      label: this.constructor.label,
      enabled: this.enabled,
      isMock: this.constructor.isMock,
      requiresOAuth: this.constructor.requiresOAuth,
      lastFetchAt: this.lastFetchAt,
      lastSuccessAt: this.lastSuccessAt,
      lastError: this.lastError,
      isStale: this.isStale(),
      refreshMinutes: this.refreshMinutes,
    };
  }
}

// Recommended cache TTLs per domain (used by ConnectorRegistry.buildDefaultRegistry
// and by the proxy server's response Cache-Control headers).
export const CACHE_TTL_MINUTES = {
  financial: 24 * 60,         // SEC filings: daily check is fine
  macro: 24 * 60,             // Most FRED/BLS series update monthly
  news: 60,                   // News refresh hourly
  markets: 15,                // Stock prices refresh more often
  'social-sentiment': 60,     // Hourly is dense enough
  'owned-social': 60,
  innovation: 7 * 24 * 60,    // Patents: weekly
  culture: 24 * 60,           // Glassdoor reviews don't change minute-to-minute
  hris: 60,
  'customer-health': 30,
  'cli-instrument': 24 * 60,
};
