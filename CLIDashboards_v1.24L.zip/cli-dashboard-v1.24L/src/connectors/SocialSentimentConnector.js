// CLI Dashboards — Social Sentiment Connector
// Domain: social-sentiment
// Returns: per-platform sentiment 0-10, mention volume, top themes, w/w deltas

import { BaseConnector } from './BaseConnector.js';

const PLATFORMS = ['x', 'linkedin', 'facebook', 'instagram', 'tiktok'];

// Deterministic pseudo-random for stable mock data across reloads
function seededRandom(seed) {
  let s = 0;
  for (let i = 0; i < seed.length; i++) s = ((s << 5) - s + seed.charCodeAt(i)) | 0;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

export class MockSocialSentimentConnector extends BaseConnector {
  static domain = 'social-sentiment';
  static label = 'Mock social sentiment (demo)';
  static isMock = true;

  async _fetch() {
    const company = this.config.companyName || 'Demo Co';
    const handles = this.config.handles || {};
    const hashtags = this.config.hashtags || [];

    const rand = seededRandom(company + (this.config.tenantId || ''));

    const platforms = {};
    for (const p of PLATFORMS) {
      const baseSentiment = 5.5 + rand() * 3; // 5.5–8.5
      const wowDelta = (rand() - 0.5) * 1.4;  // -0.7 to +0.7
      const volume = Math.round(50 + rand() * 950);
      const coverage = (p === 'linkedin' || p === 'facebook' || p === 'instagram')
        ? 'public-mentions-only' : 'full';
      platforms[p] = {
        platform: p,
        handle: handles[p] || null,
        sentiment: Number(baseSentiment.toFixed(1)),
        sentimentWoW: Number(wowDelta.toFixed(2)),
        volume,
        coverage,
        topThemes: this._mockThemes(rand, company, p),
      };
    }

    // Overall sentiment = volume-weighted average
    const totalVolume = Object.values(platforms).reduce((a, b) => a + b.volume, 0);
    const overallSentiment = totalVolume > 0
      ? Object.values(platforms).reduce((a, b) => a + b.sentiment * b.volume, 0) / totalVolume
      : 0;

    return {
      company,
      hashtags,
      overallSentiment: Number(overallSentiment.toFixed(1)),
      totalVolume,
      platforms,
      note: 'MOCK DATA — replace with Brand24, Brandwatch, or custom connector for real customer data.',
    };
  }

  _mockThemes(rand, company, platform) {
    const pools = {
      x: ['product launch chatter', 'CEO mention', 'pricing complaints', 'competitor comparison', 'announcement reaction'],
      linkedin: ['hiring posts', 'leadership content', 'industry commentary', 'partnership news', 'team culture'],
      facebook: ['community posts', 'customer feedback', 'event coverage', 'brand storytelling'],
      instagram: ['behind-the-scenes', 'employee spotlights', 'product imagery', 'event reels'],
      tiktok: ['employee creator content', 'industry trends', 'product demos', 'brand challenges'],
    };
    const pool = pools[platform] || ['general mentions'];
    const count = 2 + Math.floor(rand() * 2);
    return Array.from({ length: count }, (_, i) => pool[Math.floor(rand() * pool.length)])
      .filter((v, i, a) => a.indexOf(v) === i);
  }
}

// Stub for Brand24 — real implementation requires API key and live testing
// against their API. Shape mirrors MockSocialSentimentConnector so swapping in
// is a 1-line change in the Tenant Config.
export class Brand24Connector extends BaseConnector {
  static domain = 'social-sentiment';
  static label = 'Brand24';
  static isMock = false;

  async _fetch() {
    if (!this.config.apiKey) throw new Error('Brand24 connector requires apiKey in config');
    const proxyBase = this.config.proxyBase || 'https://cli-proxy.vercel.app';
    const projectId = this.config.projectId;
    if (!projectId) throw new Error('Brand24 connector requires projectId in config');

    // Real implementation routes through proxy so the API key stays server-side
    const res = await fetch(`${proxyBase}/api/brand24?projectId=${projectId}`);
    if (!res.ok) throw new Error(`Brand24 proxy error ${res.status}`);
    const data = await res.json();
    return data; // Proxy returns the same shape as MockSocialSentimentConnector
  }
}
