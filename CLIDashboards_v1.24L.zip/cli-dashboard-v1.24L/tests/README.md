# CLI Dashboards — Automated E2E Tests with Video Recording

Tests three dashboards: **OASI**, **Aspirational OASI (A-OASI)**, and **Fill Jobs**.
Each test runs the dashboard for ~30 seconds while scrolling and clicking
non-destructive elements, so the recorded video shows real interaction.

## One-time setup

```bash
# From the project root:
npm install
npx playwright install chromium
```

`npx playwright install chromium` downloads the browser binary Playwright
drives. You only need to do this once per machine.

## Run all three tests (recommended)

```bash
npm run test:e2e
```

This will:
1. Start the Vite dev server (`npm run dev`) automatically.
2. Open each dashboard in headless Chromium.
3. Spend ~30s exercising each one.
4. Write a video to `test-results/<test-name>/video.webm`.
5. Tear down the dev server.

## Watch the tests live (non-headless)

```bash
npm run test:e2e:headed
```

A browser window will open and you can watch each dashboard being exercised.
Videos are still recorded.

## Run only one dashboard

```bash
# OASI only
npx playwright test -g "OASI dashboard"

# A-OASI only
npx playwright test -g "Aspirational OASI"

# Fill Jobs only
npx playwright test -g "Fill Jobs"
```

## Open the HTML report (includes inline video player)

```bash
npm run test:e2e:report
```

A local browser tab opens with a structured report. Each test has a "Video"
attachment that plays inline.

## Where the videos land

```
test-results/
├── dashboards-OASI-dashboard---30s-exercise-chromium/
│   └── video.webm
├── dashboards-Aspirational-OASI--A-OASI--dashboard---30s-exercise-chromium/
│   └── video.webm
└── dashboards-Fill-Jobs-dashboard---30s-exercise-chromium/
    └── video.webm
```

`.webm` plays in Chrome, Firefox, and VLC out of the box. To convert to mp4:

```bash
ffmpeg -i test-results/.../video.webm -c:v libx264 -crf 20 oasi.mp4
```

## Customizing dwell time

Change `DWELL_MS` at the top of `tests/dashboards.spec.js` (default `30_000`).
