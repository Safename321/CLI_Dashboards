// @ts-check
const { test, expect } = require('@playwright/test');

/**
 * Visits OASI, Aspirational OASI (A-OASI), and Fill Jobs dashboards.
 * Each test spends ~30 seconds exercising the board so the recorded video
 * captures meaningful interaction, not just a static page.
 *
 * Videos are written to:  test-results/<test-id>/video.webm
 */

const DWELL_MS = 30_000;                 // ~30 sec per dashboard
const SCROLL_EVERY_MS = 1_500;           // gentle scroll cadence during dwell
const POLL_BUTTONS_EVERY_MS = 4_000;     // poke an interactive element periodically

/**
 * Dwell on the current page for ~`dwellMs`. During the dwell we periodically:
 *   - scroll the main content
 *   - click any visible "tab"-style sub-button to surface different sub-views
 *   - hover the radar / chart area if present
 * The goal is a watchable demo, not a unit assertion.
 */
async function exerciseDashboard(page, dashboardName, dwellMs = DWELL_MS) {
  const start = Date.now();
  let scrollY = 0;
  let lastButtonPokeAt = 0;
  let pokeIndex = 0;

  while (Date.now() - start < dwellMs) {
    const elapsed = Date.now() - start;

    // Gentle scroll cycle
    scrollY = (scrollY + 240) % 1600;
    await page.evaluate((y) => window.scrollTo({ top: y, behavior: 'smooth' }), scrollY);

    // Every few seconds, click a non-nav button to vary what's on screen
    if (elapsed - lastButtonPokeAt > POLL_BUTTONS_EVERY_MS) {
      lastButtonPokeAt = elapsed;
      const candidates = await page.locator('button').all();
      // Filter to buttons in main content (skip the left rail nav so we don't leave the dashboard)
      const inMain = [];
      for (const b of candidates) {
        try {
          const box = await b.boundingBox();
          if (!box) continue;
          if (box.x < 240) continue;                        // skip left rail
          if (box.width < 20 || box.height < 20) continue;  // skip tiny icons
          if (!(await b.isVisible())) continue;
          const txt = (await b.innerText().catch(() => '')).trim();
          // Skip destructive / report-generation buttons during the dwell
          if (/generate|download|export|report|clear all|remove/i.test(txt)) continue;
          inMain.push(b);
        } catch { /* element churn, ignore */ }
      }
      if (inMain.length > 0) {
        const target = inMain[pokeIndex % inMain.length];
        pokeIndex++;
        try {
          await target.scrollIntoViewIfNeeded({ timeout: 1000 });
          await target.click({ timeout: 1500, trial: false });
        } catch { /* button vanished mid-click; that's fine */ }
      }
    }

    await page.waitForTimeout(SCROLL_EVERY_MS);
  }

  console.log(`[${dashboardName}] dwell complete (~${Math.round((Date.now() - start)/1000)}s)`);
}

/**
 * Click a left-rail nav button by visible label. Handles the case where the
 * label appears in multiple places by picking the one in the sidebar.
 */
async function openDashboard(page, label) {
  // The left rail buttons render the label as a <span>. Click the closest button.
  const navButton = page
    .locator('button', { has: page.locator(`span:text-is("${label}")`) })
    .first();
  await expect(navButton).toBeVisible({ timeout: 15_000 });
  await navButton.click();
  // Let the dashboard mount / charts settle
  await page.waitForTimeout(1200);
}

test.beforeEach(async ({ page }) => {
  await page.goto('/');
  // Wait for the app shell — overview is the default page
  await expect(page.locator('text=Overview').first()).toBeVisible({ timeout: 30_000 });
});

test('OASI dashboard — 30s exercise', async ({ page }) => {
  await openDashboard(page, 'OASI');
  // Sanity: some OASI-specific content should appear
  await expect(page.locator('text=/Style Scores|Stated Values|Achieving Style/i').first())
    .toBeVisible({ timeout: 10_000 });
  await exerciseDashboard(page, 'OASI');
});

test('Aspirational OASI (A-OASI) dashboard — 30s exercise', async ({ page }) => {
  await openDashboard(page, 'Aspirational OASI');
  await expect(page.locator('text=/Ideal|Aspirational|Current vs/i').first())
    .toBeVisible({ timeout: 10_000 });
  await exerciseDashboard(page, 'Aspirational OASI');
});

test('Fill Jobs dashboard — 30s exercise', async ({ page }) => {
  await openDashboard(page, 'Fill Jobs');
  // Soft assertion only — page may use different copy; we mainly want the dwell + video
  await page.waitForTimeout(1500);
  await exerciseDashboard(page, 'Fill Jobs');
});
