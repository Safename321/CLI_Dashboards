# CLI Dashboard — Version Bump Checklist

When bumping the dashboard version (e.g. `v1.24B` → `v1.24B`), update **all 16** locations below. Missing any one leaves a stale version visible somewhere — in the UI, in a generated report PDF, in `package.json`, or on the delivered zip filename.

History note: a previous "8 places" mental model was incomplete and let `README.md` drift to `v1.14` while the rest of the project moved through five version cycles. This checklist replaces it.

---

## The 16 locations

### `src/App.jsx` — 10 inline string literals
These are scattered throughout the file. Some appear in JSX text, some inside HTML strings being concatenated for the downloadable report tabs. They all show `v1.XX` in the format `CLI Dashboard v1.XX` or just `v1.XX` standalone.

| # | Approx. line | Context |
|---|---|---|
| 1 | ~941  | OASI explainer report footer |
| 2 | ~1023 | OASI explainer methodology disclaimer |
| 3 | ~1260 | Manager training report footer page 1 |
| 4 | ~1294 | Manager training report disclaimer |
| 5 | ~1296 | Manager training report footer page 2 |
| 6 | ~1780 | Overview & Guide dashboard subtitle |
| 7 | ~2260 | Further Reading dashboard subtitle |
| 8 | ~2540 | Sidebar footer version badge |
| 9 | ~7726 | AI Mentor session report footer |
| 10 | ~8167 | Fill Jobs dashboard section comment |

Line numbers drift as code is added — **always grep, don't trust line numbers**.

### `index.html` — 1 location
- Browser tab `<title>CLI Dashboard v1.XX</title>`

### `package.json` — 1 location
- `"version": "1.XX.0"` (note: no `v` prefix, full semver)

### `README.md` — 2 locations
- Title `# CLI Dashboard v1.XX`
- Section heading `## What's New in v1.XX`

### Filesystem — 2 locations
- Folder name `cli-dashboard-v1.XX/`
- Zip filename `CLIDashboards_v1.XX.zip`

---

## The bump procedure

Replace `OLD` and `NEW` with the actual versions (e.g. `OLD=1.20`, `NEW=1.21`).

```bash
# 1. Audit — every location that needs to change
grep -rn "v$OLD\|V$OLD\|$OLD\.0" \
  --include="*.jsx" --include="*.js" --include="*.json" \
  --include="*.html" --include="*.md" --include="*.css" . \
  | grep -v node_modules | grep -v package-lock

# 2. Bump the code/text files
sed -i "s/v$OLD/v$NEW/g; s/V$OLD/V$NEW/g" src/App.jsx index.html README.md
sed -i "s/\"version\": \"$OLD.0\"/\"version\": \"$NEW.0\"/" package.json

# 3. Verify — must return ZERO hits before sealing the zip
grep -rn "v$OLD\|V$OLD\|$OLD\.0" \
  --include="*.jsx" --include="*.js" --include="*.json" \
  --include="*.html" --include="*.md" --include="*.css" . \
  | grep -v node_modules | grep -v package-lock \
  || echo "✓ Clean — no stale version strings remain"

# 4. Rename the folder
cd .. && mv cli-dashboard-v$OLD cli-dashboard-v$NEW && cd cli-dashboard-v$NEW

# 5. Build the zip (with the new filename)
rm -f /mnt/user-data/outputs/CLIDashboards_v$NEW.zip
cd .. && zip -qr /mnt/user-data/outputs/CLIDashboards_v$NEW.zip \
  cli-dashboard-v$NEW/ \
  -x "cli-dashboard-v$NEW/node_modules/*" \
  -x "cli-dashboard-v$NEW/dist/*" \
  -x "cli-dashboard-v$NEW/test-results/*" \
  -x "cli-dashboard-v$NEW/playwright-report/*"
```

---

## The two failure modes that have happened

1. **README drift.** `README.md` was not in any earlier sed sweep, so it sat at `v1.14` while everything else advanced to `v1.19`. Anyone reading the repo got a misleading picture of "what's new." Fix: always include `README.md` in the sed targets.

2. **Filename/folder mismatch.** A zip named `CLIDashboards_v1.24B.zip` containing a folder called `cli-dashboard-v1.19/` looks broken on extraction. Fix: rename the folder *before* zipping, and have the zip command use the new folder name.

---

## When this checklist needs updating

If a new file or new inline `v1.XX` reference is added to the codebase, append it to the table above before merging. The audit `grep` in step 1 will surface new locations the first time it's run after they're added — the checklist exists so they get *recorded*, not just fixed once.

Last updated for v1.24E release.
